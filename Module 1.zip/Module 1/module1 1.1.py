﻿import pygame
from pygame.locals import *
import time
import math

pygame.init()

Fenetre = pygame.display.set_mode((1366,768))
pygame.display.set_caption("Module 1")
Horloge = pygame.time.Clock()

Couleur_Equipe = ((0,0,100),(100,0,0))
Etat_Jeu = 0

GrandePolice = pygame.font.Font("7-segment.ttf",60)
Police = pygame.font.Font("7-segment.ttf",20)

Hit = pygame.mixer.Sound("Hit_Hurt5.wav")
pygame.mixer.music.load("Boss_Theme.wav")

def Collision(obj1,obj2):
    if obj1.right < obj2.left:
        return False
    if obj1.bottom < obj2.top:
        return False
    if obj1.left > obj2.right:
        return False
    if obj1.top > obj2.bottom:
        return False
    return True

def Commandes_Jeu():
    Touches = pygame.key.get_pressed()

    if joystick_count == 1:
        if joystick.get_hat(0)[0] == 1: # Déplacement droite
            Joueur1.Droite()
        if joystick.get_hat(0)[0] == -1: # Déplacement gauche
            Joueur1.Gauche()
        if joystick.get_hat(0)[1] == 1: # Déplacement haut
            Joueur1.Haut()
        if joystick.get_hat(0)[1] == -1: # Déplacement Bas
            Joueur1.Bas()
        if joystick.get_axis(0) > 0.1: # Déplacement droite
            Joueur1.Droite()
        if joystick.get_axis(0) < -0.1: # Déplacement gauche
            Joueur1.Gauche()
        if joystick.get_axis(1) < -0.1: # Déplacement haut
            Joueur1.Haut()
        if joystick.get_axis(1) > 0.1: # Déplacement Bas
            Joueur1.Bas()
        if joystick.get_button(0) == 1: # Light Punch
            Joueur1.Tir()
        if joystick.get_button(1) == 1: # Light Punch
            Joueur1.Tir0()

    else:
        if Touches[K_d]: # Déplacement droite
            Joueur1.Droite()
        if Touches[K_q]: # Déplacement gauche
            Joueur1.Gauche()
        if Touches[K_z]: # Déplacement haut
            Joueur1.Haut()
        if Touches[K_s]: # Déplacement Bas
            Joueur1.Bas()
        if Touches[K_SPACE]:
            Joueur1.Tir0()
        if Touches[K_v]:
            Joueur1.Tir()

    if Touches[K_RIGHT]:
        Joueur2.Droite()
    if Touches[K_LEFT]:
        Joueur2.Gauche()
    if Touches[K_UP]:
        Joueur2.Haut()
    if Touches[K_DOWN]:
        Joueur2.Bas()
    if Touches[K_KP_ENTER]:
        Joueur2.Tir()
    if Touches[K_KP_PLUS]:
        Joueur2.Tir0()

class Classe_Balle(pygame.sprite.Sprite):
    def __init__(self):
        self.image = pygame.Surface((41,41))
        pygame.draw.circle(self.image,(255,0,0),(20,20),20)
        self.rect = self.image.get_rect().move(663,364)
        self.image.set_colorkey((0,0,0))
        self.Vitesse_X = 0
        self.Vitesse_Y = 0
        self.Acceleration = 2
        self.mask = pygame.mask.from_surface(self.image)

    def Affiche(self):
        Fenetre.blit(self.image,self.rect)
        self.rect = self.rect.move(self.Vitesse_X,self.Vitesse_Y)

        if pygame.sprite.collide_mask(self,Joueur1):
            self.Vitesse_X = self.Acceleration * abs(math.cos(Joueur1.X)) + abs(Joueur1.Vitesse_X)
            self.Vitesse_Y =Joueur1.Vitesse_Y + self.Acceleration * math.sin(2*Joueur1.X)
            self.Acceleration += 0.1
##            Hit.play()

        if pygame.sprite.collide_mask(self,Joueur2):
            self.Vitesse_X = -(self.Acceleration * abs(math.cos(Joueur2.X)) + abs(Joueur2.Vitesse_X))
            self.Vitesse_Y = Joueur2.Vitesse_Y + self.Acceleration * -math.sin(2*Joueur2.X)
            self.Acceleration += 0.1
##            Hit.play()

        if self.rect[1] < 100:
            self.Vitesse_Y = -self.Vitesse_Y
        elif self.rect[1] > 666:
            self.Vitesse_Y = -self.Vitesse_Y

        if self.rect[0] < -40:
            self.__init__()
            Sol.ScoreJ2 += 1
        elif self.rect[0] > 1366:
            self.__init__()
            Sol.ScoreJ1 += 1

class Classe_Personnage(pygame.sprite.Sprite):
    def __init__(self,Equipe):
        self.Equipe = Equipe - 1
        self.image = pygame.Surface((180,180))
        pygame.draw.rect(self.image,(Couleur_Equipe[self.Equipe]),(80,0,20,60))
        pygame.draw.circle(self.image,(Couleur_Equipe[self.Equipe]),(90,90),20)
        self.image = pygame.transform.rotate(self.image,(90 - 180*(self.Equipe)))
        self.image.set_colorkey((0,0,0))
        self.rect = self.image.get_rect().move(80+((self.Equipe)*1060),340)
        self.mask = pygame.mask.from_surface(self.image)
        self.Direction = 1 - ((self.Equipe)*2)
        self.Vitesse_X = 0
        self.Vitesse_Y = 0
        self.Delai = 0
        self.Dash_Ok = True
        self.X = 0
        self.TirOk = True
        self.DelaiTir = 0
        self.DirectionTir = 0

    def Affiche(self):
        self.image0 = pygame.Surface((180,180))
        temp = pygame.transform.rotate(self.image,self.X)
        dec = (temp.get_size()[0]-180)//2
        self.image0.blit(temp,(0,0),(dec,dec,180,180))
        self.image0.set_colorkey((0,0,0))
        Fenetre.blit(self.image0,self.rect)
        self.mask = pygame.mask.from_surface(self.image0)
        self.rect = self.rect.move(self.Vitesse_X,self.Vitesse_Y)

        if self.Vitesse_X > 0:
            self.Vitesse_X -= 1
        elif self.Vitesse_X < 0:
            self.Vitesse_X  += 1
        if self.Vitesse_Y > 0:
            self.Vitesse_Y -= 1
        elif self.Vitesse_Y < 0:
            self.Vitesse_Y  += 1

        if self.Equipe == 0:
            if self.rect[0] > 583:
                self.rect[0] -= 5
        elif self.Equipe == 1:
            if self.rect[0] < 603:
                self.rect[0] += 5

        if self.TirOk == False:
            self.Tir1()

    def Haut(self):
        self.Vitesse_Y = -5

    def Bas(self):
        self.Vitesse_Y = 5

    def Droite(self):
        self.Vitesse_X = 5

    def Gauche(self):
        self.Vitesse_X = -5

    def Tir(self):
        if self.TirOk == True:
            self.TirOk = False
            self.DirectionTir = -1
##            Hit.play()


    def Tir0(self):
        if self.TirOk == True:
            self.TirOk = False
            self.DirectionTir = 1
##            Hit.play()

    def Tir1(self):
        if self.DelaiTir < 20:
            self.X += 1*self.DelaiTir*self.DirectionTir
            self.DelaiTir += 1
        else:
            if abs(self.X) > 0:
                self.X -= 10*self.DirectionTir
            else:
                self.DelaiTir = 0
                self.TirOk = True

    def Dash(self):
        if self.Dash_Ok == True:
            self.Vitesse_X = 40*self.Direction

    def IA_Enfer(self):
        if Balle.rect[1] > self.rect[1]:
            self.Bas()
        elif Balle.rect[1] < self.rect[1]:
            self.Haut()
        if Collision(self.rect,Balle.rect):
            if self.rect[1] > Balle.rect[1]:
                self.Tir0()
            else:
                self.Tir()

    def IA_Adaptation(self):
        self.Vision = 100
        if self.Equipe == 0:
            self.Vision = 100 + Sol.ScoreJ2*40 - Sol.ScoreJ1*40
            if Balle.rect[0] - self.rect[0] < self.Vision:
                if Balle.rect[1] > self.rect[1]:
                    self.Bas()
                elif Balle.rect[1] < self.rect[1]:
                    self.Haut()
        elif self.Equipe == 1:
            self.Vision = 100 + Sol.ScoreJ1*40 - Sol.ScoreJ2*40
            if  self.rect[0] - Balle.rect[0] < self.Vision:
                if Balle.rect[1] > self.rect[1]:
                    self.Bas()
                elif Balle.rect[1] < self.rect[1]:
                    self.Haut()
        if Collision(self.rect,Balle.rect): # Tir si proche
            if self.rect[1]+90 > Balle.rect[1]:
                self.Tir0()
            else:
                self.Tir()

    def IA_Aggressive(self):
        if Collision(self.rect,Balle.rect): # Tir si proche
             if self.rect[1] + 90 > Balle.rect[1]:
                self.Tir0()
             else:
                self.Tir()
        if Balle.rect[0] > 663 and (self.rect[0] + 100 - Balle.rect[0]) > 0:
        # Si la balle est dans son camp et la balle devant lui
            if self.rect[0] > 683: # S'approche de la balle
                self.Gauche()
            if Balle.rect[1] > self.rect[1]: # Monte si la balle est au dessus
                self.Bas()
            elif Balle.rect[1] < self.rect[1]: # Descend si la balle est en dessous
                self.Haut()
        elif Balle.rect[0] > 663 and (Balle.rect[0] + 100 - self.rect[0]) > 0:
            if self.rect[0] < 1166:
                self.Droite()
            if Balle.rect[1] > self.rect[1]:
                self.Bas()
            elif Balle.rect[1] < self.rect[1]:
                self.Haut()
        else:
            if self.rect[0] < 1166:
                self.rect[0] += 5

    def IA_Enfer2(self):
        if Collision(self.rect,Balle.rect): # Tir si proche
            if self.rect[1] + 90 > Balle.rect[1]:
                self.Tir0()
            else:
                self.Tir()
        if self.Equipe == 1:
            if Balle.Vitesse_X >= 0:
                if Balle.rect[0] - self.rect[0] < 0:
                    self.Gauche()
                else:
                    self.Droite()
                if Balle.rect[1] - 90 > self.rect[1]:
                    self.Bas()
                elif Balle.rect[1] - 90 < self.rect[1]:
                    self.Haut()
            else:
                if self.rect[0] < 1166:
                    self.Droite()
                if self.rect[1] > 350:
                    self.Haut()
                elif self.rect[1] < 340:
                    self.Bas()

        elif self.Equipe == 0:
            if Balle.Vitesse_X <= 0:
                if Balle.rect[0] - self.rect[0] < 0:
                    self.Gauche()
                else:
                    self.Droite()
                if Balle.rect[1] - 90 > self.rect[1]:
                    self.Bas()
                elif Balle.rect[1] - 90 < self.rect[1]:
                    self.Haut()
            else:
                if self.rect[0] > 0:
                    self.Gauche()
                if self.rect[1] > 350:
                    self.Haut()
                elif self.rect[1] < 340:
                    self.Bas()

class Sol_Class(pygame.sprite.Sprite):
    def __init__(self):
        # Creation du fond
        self.image = pygame.Surface((1366,768))
        pygame.draw.rect(self.image,(187,95,46),(0,0,1366,768))
        pygame.draw.line(self.image,(255,255,255),(0,700),(1366,700),5)
        pygame.draw.line(self.image,(255,255,255),(0,100),(1366,100),5)
        pygame.draw.line(self.image,(255,255,255),(683,100),(683,700),5)
        pygame.draw.line(self.image,(255,255,255),(100,100),(100,700),5)
        pygame.draw.line(self.image,(255,255,255),(1266,100),(1266,700),5)
        pygame.draw.line(self.image,(255,255,255),(100,400),(1266,400),5)

        pygame.draw.rect(self.image,(0,0,0),(526,3,314,84))
        pygame.draw.rect(self.image,(255,255,255),(528,5,310,80))
        pygame.draw.rect(self.image,(0,0,0),(533,20,300,60))

        pygame.draw.rect(self.image,(63,63,63),(633,25,100,20))
        pygame.draw.rect(self.image,(63,63,63),(660,47,48,28))

        self.rect = self.image.get_rect()
        self.ScoreJ1 = 00
        self.ScoreJ2 = 00

    def Affiche(self):
        Fenetre.blit(self.image,self.rect)

        Fenetre.blit(Police.render("TIME",0,(255,255,255)),(655,27))
        Fenetre.blit(Police.render("00",0,(255,255,255)),(670,52))

        Fenetre.blit(GrandePolice.render('%02d '%(self.ScoreJ1),0,(242,188,82)),(540,30))
        Fenetre.blit(GrandePolice.render('%02d '%(self.ScoreJ2),0,(242,188,82)),(740,30))

class Menu_Class(pygame.sprite.Sprite):
    def __init__(self):
        # Création du fond
        self.image = pygame.Surface((1366,768))
        pygame.draw.rect(self.image,(187,95,46),(0,0,1366,768))
        pygame.draw.line(self.image,(255,255,255),(0,700),(1366,700),5)
        pygame.draw.line(self.image,(255,255,255),(0,100),(1366,100),5)
        pygame.draw.rect(self.image,(0,0,0),(526,3,314,84))
        pygame.draw.rect(self.image,(255,255,255),(528,5,310,80))
        pygame.draw.rect(self.image,(0,0,0),(533,20,300,60))
        pygame.draw.rect(self.image,(63,63,63),(633,25,100,20))
        pygame.draw.rect(self.image,(63,63,63),(660,47,48,28))

        self.rect = self.image.get_rect()
        self.ScoreJ1 = 00
        self.ScoreJ2 = 00
        self.Etat_Menu = 0
        self.Etat_Menu_1 = -1
        self.Select = 0

    def Affiche(self):
        Fenetre.blit(self.image,self.rect)

        Fenetre.blit(Police.render("TIME",0,(255,255,255)),(655,27))
        Fenetre.blit(Police.render("00",0,(255,255,255)),(670,52))

        Fenetre.blit(GrandePolice.render('%02d '%(self.ScoreJ1),0,(242,188,82)),(540,30))
        Fenetre.blit(GrandePolice.render('%02d '%(self.ScoreJ2),0,(242,188,82)),(740,30))

        if self.Etat_Menu_1 == -1: # Menu principal
            Fenetre.blit(GrandePolice.render("Bienvenue sur module1",0,(255,255,255)),(120,150))
            if self.Etat_Menu == 0: # Etat 0
                Fenetre.blit(GrandePolice.render("-Solo",0,(255,255,255)),(120,300))
                Fenetre.blit(GrandePolice.render("Multijoeur",0,(255,255,255)),(120,450))
                Fenetre.blit(GrandePolice.render("Options",0,(255,255,255)),(120,600))

            elif self.Etat_Menu == 1: # Etat 1
                Fenetre.blit(GrandePolice.render("Solo",0,(255,255,255)),(120,300))
                Fenetre.blit(GrandePolice.render("-Multijoeur",0,(255,255,255)),(120,450))
                Fenetre.blit(GrandePolice.render("Options",0,(255,255,255)),(120,600))

            elif self.Etat_Menu == 2: # Etat 2
                Fenetre.blit(GrandePolice.render("Solo",0,(255,255,255)),(120,300))
                Fenetre.blit(GrandePolice.render("Multijoeur",0,(255,255,255)),(120,450))
                Fenetre.blit(GrandePolice.render("-Options",0,(255,255,255)),(120,600))

        elif self.Etat_Menu_1 == 0: # Menu solo
            Fenetre.blit(GrandePolice.render("Choix de l'adversaire",0,(255,255,255)),(120,150))
            if self.Select == 0: # IA adaptative
                Fenetre.blit(GrandePolice.render("-Adaptatif",0,(255,255,255)),(120,300))
                Fenetre.blit(GrandePolice.render("Aggressif",0,(255,255,255)),(120,450))
                Fenetre.blit(GrandePolice.render("Enfer",0,(255,255,255)),(120,600))

            elif self.Select == 1: # IA aggressive
                Fenetre.blit(GrandePolice.render("Adaptatif",0,(255,255,255)),(120,300))
                Fenetre.blit(GrandePolice.render("-Aggressif",0,(255,255,255)),(120,450))
                Fenetre.blit(GrandePolice.render("Enfer",0,(255,255,255)),(120,600))

            elif self.Select == 2: # IA infernale
                Fenetre.blit(GrandePolice.render("Adaptatif",0,(255,255,255)),(120,300))
                Fenetre.blit(GrandePolice.render("Aggressif",0,(255,255,255)),(120,450))
                Fenetre.blit(GrandePolice.render("-Enfer",0,(255,255,255)),(120,600))

        elif self.Etat_Menu_1 == 1: # Menu multijoueur
            Fenetre.blit(GrandePolice.render("Bah vas-y appuie!!!",0,(255,255,255)),(120,150))

        elif self.Etat_Menu_1 == 2: # Menu Options
            if joystick_count == 0:
                Fenetre.blit(GrandePolice.render("Manette non connectee",0,(255,255,255)),(120,150))
            elif joystick_count == 1:
                Fenetre.blit(GrandePolice.render("Manette connectee",0,(255,255,255)),(120,150))


Marche = True

# Création des objets
Menu = Menu_Class()
Sol = Sol_Class()
Balle = Classe_Balle()
Joueur1 = Classe_Personnage(1)
Joueur2 = Classe_Personnage(2)
play = True

while Marche:
    if play:
        pygame.mixer.music.play(7)
        play = False
    Horloge.tick(120)
    Fenetre.fill((255,255,255))

    # Initialisation de la manette
    pygame.joystick.init()
    joystick_count = pygame.joystick.get_count()
    for i in range(joystick_count):
        joystick = pygame.joystick.Joystick(i)
        joystick.init()

    if Etat_Jeu == 0: # Mode menu
        Menu.Affiche()
        for event in pygame.event.get():
            if event.type == QUIT:
                Marche=False

            if Menu.Etat_Menu_1 == -1: # Menu principal
                Menu.Select = 0

                if joystick_count == 1: # Commandes menu principal manette
                    if joystick.get_hat(0)[1] == -1:
                        Menu.Etat_Menu = (Menu.Etat_Menu + 1) % 3
                    elif joystick.get_hat(0)[1] == 1:
                        Menu.Etat_Menu = (Menu.Etat_Menu - 1) % 3
                    elif joystick.get_button(1) == 1:
                        Menu.Etat_Menu_1 = Menu.Etat_Menu


                if event.type == KEYDOWN: # Commandes menu principal clavier
                    if event.key == K_ESCAPE:
                        Marche=False
                    elif event.key == K_z:
                        Menu.Etat_Menu = (Menu.Etat_Menu - 1) % 3
                    elif event.key == K_s:
                        Menu.Etat_Menu = (Menu.Etat_Menu + 1) % 3
                    elif event.key == K_RETURN:
                        Menu.Etat_Menu_1 = Menu.Etat_Menu

            elif Menu.Etat_Menu_1 == 0: # Menu solo

                if joystick_count == 1: # Commandes menu solo manette
                    if joystick.get_hat(0)[1] == -1:
                        Menu.Select = (Menu.Select + 1) % 3
                    elif joystick.get_hat(0)[1] == 1:
                        Menu.Select = (Menu.Select - 1) % 3
                    elif joystick.get_button(1) == 1:
                        Etat_Jeu = 1
                    elif joystick.get_button(2) == 1:
                        Menu.Etat_Menu_1 = -1

                if event.type == KEYDOWN: # Commandes menu solo clavier
                    if event.key == K_ESCAPE:
                        Menu.Etat_Menu_1 = -1
                    elif event.key == K_z:
                        Menu.Select = (Menu.Select - 1) % 3
                    elif event.key == K_s:
                        Menu.Select = (Menu.Select + 1) % 3
                    elif event.key == K_RETURN:
                        Etat_Jeu = 1

            elif Menu.Etat_Menu_1 == 1: # Menu multijoueur

                if joystick_count == 1: # Commandes menu multijoueur manette
                    if joystick.get_button(2) == 1:
                        Menu.Etat_Menu_1 = -1
                    elif joystick.get_button(1) == 1:
                        Etat_Jeu = 1
                        Menu.Select = -1

                if event.type == KEYDOWN: # Commandes menu multijoueur clavier
                    if event.key == K_ESCAPE:
                        Menu.Etat_Menu_1 = -1
                    elif event.key == K_RETURN:
                        Etat_Jeu = 1
                        Menu.Select = -1

            elif Menu.Etat_Menu_1 == 2: # Menu options

                if joystick_count == 1: # Commandes menu options manette
                    if joystick.get_button(2) == 1:
                        Menu.Etat_Menu_1 = -1

                if event.type == KEYDOWN: # Commandes menu option clavier
                    if event.key == K_ESCAPE:
                        Menu.Etat_Menu_1 = -1

    elif Etat_Jeu == 1: # Mode jeu
        for event in pygame.event.get():
            if event.type == QUIT:
                Marche=False
            if event.type == KEYDOWN:
                if event.key == K_ESCAPE:
                    Etat_Jeu = 0
                    Joueur1.__init__(1)
                    Joueur2.__init__(2)
                    Sol.__init__()
                    Balle.__init__()

            if joystick_count == 1:
                if joystick.get_button(2) == 1:
                    Etat_Jeu = 0
                    Joueur1.__init__(1)
                    Joueur2.__init__(2)
                    Sol.__init__()
                    Balle.__init__()

        # Affichage en jeu

        Sol.Affiche()
        Joueur1.Affiche()
        Joueur2.Affiche()
        Balle.Affiche()

        # IA choisie pour le mode solo
        if Menu.Select == 0:
            Joueur2.IA_Adaptation()
        elif Menu.Select == 1:
##            Joueur1.IA_Aggressive()
            Joueur2.IA_Aggressive()
        elif Menu.Select == 2:
##            Joueur1.IA_Enfer2()
            Joueur2.IA_Enfer2()

        Commandes_Jeu()

    pygame.display.flip()
pygame.quit()